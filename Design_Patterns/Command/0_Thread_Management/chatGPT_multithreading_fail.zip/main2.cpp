#include <iostream>
#include <thread>
#include <vector>
#include <queue>
#include <atomic>
#include <condition_variable>

class Task {
public:
    virtual void execute() = 0;
    virtual ~Task() {}
};

class ConcreteTask : public Task {
private:
    int taskId;
public:
    ConcreteTask(int id) : taskId(id) {}
    void execute() override {
        std::cout << "Task " << taskId << " executed" << std::endl;
    }
    int getId() const { return taskId; }
};

class Worker {
private:
    int workerId;
    std::thread workerThread;
    std::queue<Task*> taskQueue;
    std::mutex mtx;
    std::atomic<bool> stopFlag{false};

    void workerLoop() {
        while (!stopFlag) {
            Task* task = nullptr;

            {
                std::lock_guard<std::mutex> lock(mtx);
                if (!taskQueue.empty()) {
                    task = taskQueue.front();
                    taskQueue.pop();
                }
            }

            if (task) {
                task->execute();
                delete task;
            } else {
                std::cout << "Worker " << workerId << " was idle" << std::endl;
            }
        }
    }

public:
    Worker(int id) : workerId(id) {
        workerThread = std::thread(&Worker::workerLoop, this);
    }

    void assignTask(Task* task) {
        std::lock_guard<std::mutex> lock(mtx);
        taskQueue.push(task);
    }

    void stop() {
        stopFlag = true;
        workerThread.join();
    }

    int getId() const { return workerId; }

    ~Worker() {
        stop();
    }
};

class Scheduler {
private:
    std::vector<Worker*> workers;
    std::queue<Task*> tasks;
    int cycleCount = 0;
    int idleCycles = 0;
    const int maxIdleCycles = 3;

public:
    Scheduler(int workerCount) {
        for (int i = 1; i <= workerCount; ++i) {
            workers.push_back(new Worker(i));
        }
    }

    void addTasks(int taskCount) {
        for (int i = 1; i <= taskCount; ++i) {
            tasks.push(new ConcreteTask(i));
        }
        std::cout << "Added " << taskCount << " tasks." << std::endl;
    }

    void start() {
        std::cout << "Starting scheduler" << std::endl;

        while (idleCycles < maxIdleCycles) {
            cycleCount++;
            std::cout << "Cycle " << cycleCount << " started" << std::endl;
            int taskAssigned = 0;

            for (auto worker : workers) {
                if (!tasks.empty()) {
                    Task* task = tasks.front();
                    tasks.pop();
                    worker->assignTask(task);
                    std::cout << "Worker " << worker->getId() << " performed task number " 
                              << dynamic_cast<ConcreteTask*>(task)->getId() << std::endl;
                    taskAssigned++;
                } else {
                    std::cout << "Worker " << worker->getId() << " was idle" << std::endl;
                }
            }

            if (taskAssigned == 0) {
                idleCycles++;
            } else {
                idleCycles = 0;
            }

            std::cout << "Cycle " << cycleCount << " ended" << std::endl;
            std::this_thread::sleep_for(std::chrono::seconds(1));  // Adding a small delay for cycle simulation.
        }

        std::cout << "Stopping due to " << maxIdleCycles << " empty cycles" << std::endl;
        std::cout << "Scheduler stopped" << std::endl;
    }

    ~Scheduler() {
        for (auto worker : workers) {
            delete worker;
        }
    }
};

int main() {
    Scheduler scheduler(2); // 2 workers
    scheduler.addTasks(5);  // Add 5 tasks
    scheduler.start();      // Start the scheduler

    return 0;
}
