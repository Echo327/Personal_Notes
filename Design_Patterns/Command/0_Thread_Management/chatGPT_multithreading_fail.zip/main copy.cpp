#include <iostream>
#include <queue>
#include <mutex>
#include <condition_variable>
#include <thread>
#include <vector>
#include <memory>
#include <chrono>

// Command Pattern Interface
class Command {
public:
    virtual void execute(int taskNumber) = 0;
    virtual ~Command() = default;
};

// Concrete Task (Command)
class PrintTask : public Command {
private:
    int taskNumber;

public:
    PrintTask(int number) : taskNumber(number) {}

    void execute(int taskNumber) override {
        std::cout << "Thread " << std::this_thread::get_id() << " performed task number " << taskNumber << std::endl;
    }
};

// Worker Class
class Worker {
private:
    std::queue<std::shared_ptr<Command>> taskQueue;
    std::mutex mtx;
    std::condition_variable cv;
    bool isRunning = false;
    int emptyCycleCount = 0;
    const int maxEmptyCycles = 3;
    int taskNumber = 1;  // Task number counter

public:
    // Add a task to the queue
    void addTask(std::shared_ptr<Command> task) {
        std::lock_guard<std::mutex> lock(mtx);
        taskQueue.push(task);
        cv.notify_all();
    }

    // Start the worker's processing
    void start() {
        isRunning = true;
        std::cout << "Thread " << std::this_thread::get_id() << " was started" << std::endl;
    }

    // Worker process to execute two tasks per cycle
    void processTasks() {
        int cycleCounter = 1;  // Cycle counter

        while (isRunning) {
            std::this_thread::sleep_for(std::chrono::milliseconds(20));  // Cyclic interval of 20 ms
            
            // Print cycle start
            std::cout << "Cycle " << cycleCounter++ << " started" << std::endl;

            std::vector<std::shared_ptr<Command>> tasksToExecute;
            {
                std::lock_guard<std::mutex> lock(mtx);

                // Collect two tasks if available
                for (int i = 0; i < 2 && !taskQueue.empty(); ++i) {
                    tasksToExecute.push_back(taskQueue.front());
                    taskQueue.pop();
                }
            }

            // If there are tasks to execute, reset the empty cycle count
            if (!tasksToExecute.empty()) {
                emptyCycleCount = 0;  // Reset empty cycle count if tasks were found
                for (auto& task : tasksToExecute) {
                    task->execute(taskNumber++);  // Execute task and increment task number
                }
            } else {
                // Increment empty cycle count if no tasks were found
                emptyCycleCount++;
            }

            // Print cycle end
            std::cout << "Cycle " << cycleCounter - 1 << " ended" << std::endl;

            // Stop processing if empty cycle count reaches the maximum
            if (emptyCycleCount >= maxEmptyCycles) {
                std::cout << "Stopping due to 3 empty cycles." << std::endl;
                isRunning = false;  // Stop the worker after 3 empty cycles
            }
        }
    }
};

// TaskScheduler Class
class TaskScheduler {
private:
    Worker& worker;
    int totalTasks;
    int tasksAdded = 0;

public:
    TaskScheduler(Worker& w, int t) : worker(w), totalTasks(t) {}

    // Add tasks to the worker
    void addTasks() {
        for (int i = 0; i < totalTasks; ++i) {
            worker.addTask(std::make_shared<PrintTask>(i + 1));
            tasksAdded++;
        }
        std::cout << "Added " << tasksAdded << " tasks." << std::endl;
    }

    // Start the task scheduler
    void start() {
        worker.start();  // Start the worker
        addTasks();  // Add the tasks to the worker's queue
    }
};

// Main Function
int main() {
    Worker worker;
    
    // Specify how many tasks you want to add (e.g., 5 tasks)
    int t = 5;
    
    // Create a scheduler with the specified number of tasks
    TaskScheduler scheduler(worker, t);

    // Start the worker's task processing in a separate thread
    std::thread workerThread(&Worker::processTasks, &worker);

    // Start the scheduler (this will add tasks and start processing)
    scheduler.start();

    // Join the worker thread to keep the main function running
    workerThread.join();

    return 0;
}

// make it so the output looks like this:

Worker 1 was started on thread 1
Worker 2 was started on thread 2
Added 5 tasks.
Starting scheduler
Cycle 1 started
Worker 1 (Thread 1) performed task number 1
Worker 2 (Thread 2) performed task number 2
Cycle 1 ended
Cycle 2 started
Worker 1 (Thread 1) performed task number 3
Worker 2 (Thread 2) performed task number 4 
Cycle 2 ended
Cycle 3 started
Worker 1 (Thread 1) performed task number 5
Worker 2 (Thread 2) was idle 
Cycle 3 ended
Cycle 4 started
Worker 1 (Thread 1) was idle 
Worker 2 (Thread 2) was idle 
Cycle 4 ended
Cycle 5 started
Worker 1 (Thread 1) was idle 
Worker 2 (Thread 2) was idle 
Cycle 5 ended
Cycle 6 started
Worker 1 (Thread 1) was idle 
Worker 2 (Thread 2) was idle 
Cycle 6 ended
Stopping due to 3 empty cycles
Scheduler stopped
